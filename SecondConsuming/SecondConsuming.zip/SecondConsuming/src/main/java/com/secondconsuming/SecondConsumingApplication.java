package com.secondconsuming;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecondConsumingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecondConsumingApplication.class, args);
	}

}
