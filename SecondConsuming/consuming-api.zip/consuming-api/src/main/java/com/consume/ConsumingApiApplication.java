package com.consume;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConsumingApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConsumingApiApplication.class, args);
	}


}
